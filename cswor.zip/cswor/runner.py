from mod_copeland import sample_complexity


args = {}
# args['heuristic'] = 'random'
args['heuristic'] = 'greedy'
args['n_voters'] = 500
args['alpha'] = 0.05
# args['probs'] = [0.4, 0.45, 0.5, 0.7, 0.8]
args['probs'] = [0.1, 0.2, 0.3, 0.4, 0.5]
args['seed'] = 42
args['ques_limit'] = 5
gammas = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
# gammas = [0.0]
greedy_itrs = []
random_itrs = []
seeds = [0, 1, 2, 3, 4, 5]
# seeds = [0]

for gamma in gammas:
    print("Gamma", gamma, "started")
    seed_vals = []
    args['gamma'] = gamma
    for seed in seeds:
        args['seed'] = seed
        itr, winner = sample_complexity(args)
        print("seed", seed, "itr", itr, "winner", winner)
        seed_vals.append(itr)
    greedy_itrs.append(seed_vals)

print(greedy_itrs)

        # print(sample_complexity(args))